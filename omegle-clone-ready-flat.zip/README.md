# omegle-clone-ready
Backend: Node.js (Express + Socket.io)
Frontend: public/
Start: npm install && npm start